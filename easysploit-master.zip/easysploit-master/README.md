# EasySploit
EasySploit v2.1 (Linux) - Metasploit automation (EASIER and FASTER than EVER) 

# Desclaimer:

 Usage of EASYSPLOIT for attacking targets without prior mutual consent is
 ILLEGAL. Developers are not responsible for any damage caused by this script.
 EASYSPLOIT is intented ONLY FOR EDUCATIONAL PURPOSES!!! STAY LEGAL!!! 
 
# Options:

(1) Windows --> test.exe (payload and listener) 

(2) Android --> test.apk (payload and listener)  

(3) Linux --> test.py (payload and listener) 

(4) MacOS --> test.jar (payload and listener)

(5) Web --> test.php (payload and listener)

(6) Scan if a target is vulnerable to ms17_010

(7) Exploit Windows 7/2008 x64 ONLY by IP (ms17_010_eternalblue)

(8) Exploit Windows Vista/XP/2000/2003 ONLY by IP (ms17_010_psexec)  

(9) Exploit Windows with a link (HTA Server)

(10) Contact with me - My accounts

# How to install:

git clone https://github.com/KALILINUXTRICKSYT/easysploit.git
 
cd easysploit

bash installer.sh

# How to run (after installation):

Type anywhere in your terminal "easysploit".

# Video tutorials:

https://www.youtube.com/watch?v=9J479dModb8

https://www.youtube.com/watch?v=UOUry9ov9rM


# Support us: 

https://www.patreon.com/kalilinuxtricks
